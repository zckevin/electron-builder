/**
 *  Commented out of using https://github.com/ArekSredzki/electron-release-server/
 */

const log = require('electron-log');
// const urlJoin = require('url-join');

function setUpdateServer(autoUpdater) {
    // let platform = ""
    // let arch = ""
    // if (process.platform === 'darwin') {
    //     platform = "osx"
    //     if (process.arch === 'arm64') {
    //         arch = 'arm64'
    //     } else {
    //         arch = '64'
    //     }
    // } else if (process.platform === 'win32') {
    //     platform = "windows"
    //     if (process.arch === 'x64') {
    //         arch = '64'
    //     } else {
    //         arch = '32'
    //     }
    // } else if (process.platform === 'linux') {
    //     platform = "linux"
    //     if (process.arch === 'x64' || process.arch === 'x86_64') {
    //         arch = '64'
    //     } else {
    //         arch = '32'
    //     }
    // }
    const baseURL = "http://192.168.123.19:18080/";
    // const apiURL = urlJoin(baseURL, "update", platform + "_" + arch, "stable");
    const apiURL = baseURL;
    log.info("===== Setting update server to:" + apiURL);
    autoUpdater.setFeedURL({
        url: apiURL,
        provider: "generic",
        channel: "asar",
        useMultipleRangeRequest: false
    });
}

module.exports = {
    setUpdateServer: setUpdateServer
}