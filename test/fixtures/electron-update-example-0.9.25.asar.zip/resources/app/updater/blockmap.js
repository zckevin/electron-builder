const appBuilder = require("app-builder-lib");

async function genBlockMap(context, updateInfo) {
  const args = ["blockmap", "--input", updateInfo.zipFilePath, "--output", updateInfo.blockmapPath];
  const blockmapInfo = await appBuilder.executeAppBuilderAsJson(args);
  console.log("genBlockMap: exec args", args, ", result", blockmapInfo);
  updateInfo.setBlockmapInfo(blockmapInfo);
}

module.exports = {
  genBlockMap,
}