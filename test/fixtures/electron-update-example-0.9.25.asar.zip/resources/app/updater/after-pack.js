const path = require('path');
const UpdateInfo = require('./update-info.js');
const { zipAsar } = require('./zip.js');
const { genBlockMap } = require('./blockmap.js');
const { genYml } = require('./yml.js');
const shelljs = require("shelljs")

function renameLinuxUnpacked(dir, updateInfo) {
  shelljs.cp("-r", dir, path.join(dir, `../linux-unpacked-${updateInfo.version}`))
}

async function afterPack(context) {
  // console.log("=== after pack", context)
  const name = context.packager.appInfo.sanitizedName;
  const version = context.packager.appInfo.version;
  const updateInfo = new UpdateInfo(name, version, context.outDir, context.appOutDir);

  await zipAsar(context, updateInfo);
  await genBlockMap(context, updateInfo);
  await genYml(context, updateInfo);

  renameLinuxUnpacked(updateInfo.appOutDir, updateInfo);
}

module.exports = {
  afterPack: afterPack,
}