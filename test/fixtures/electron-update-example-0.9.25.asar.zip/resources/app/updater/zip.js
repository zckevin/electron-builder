const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
// const AdmZip = require("adm-zip");

async function zipAsar(context, updateInfo) {
	// e.g. //electron-updater-example/dist/linux-unpacked/resources
	const resourcesDir = path.join(updateInfo.appOutDir, 'resources');
	const output = fs.createWriteStream(updateInfo.zipFilePath);

	const archive = archiver('zip', {
		zlib: { level: 1 } // fastest
	});

	return new Promise((resolve, reject) => {
		output.on('close', function () {
			console.log(archive.pointer() + ' total bytes');
			console.log('archiver has been finalized and the output file descriptor has closed.');
			resolve()
		});

		// good practice to catch warnings (ie stat failures and other non-blocking errors)
		archive.on('warning', function (err) {
			if (err.code === 'ENOENT') {
				// log warning
			} else {
				// throw error
				throw err;
			}
		});

		// good practice to catch this error explicitly
		archive.on('error', function (err) {
			throw err;
		});

		archive.pipe(output);

		archive.directory(resourcesDir, 'resources');
		archive.finalize();
	})
	// const zip = new AdmZip();
	// zip.addLocalFolder(resourcesDir, 'resources');
	// zip.writeZip(updateInfo.zipFilePath);
}

module.exports = {
	zipAsar,
}