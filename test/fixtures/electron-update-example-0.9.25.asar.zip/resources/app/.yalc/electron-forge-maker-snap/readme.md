# electron-installer-snap

[electron-builder](https://github.com/electron-userland/electron-builder) [snap](https://snapcraft.io) target for electron-forge.

Recommended to build electron-forge project using electron-builder directly.
[Publishing](https://www.electron.build/configuration/publish),
[Auto Update](https://electron.build/auto-update)
and [Code Signing](https://electron.build/code-signing) supported only in this case
(including all other useful [packaging options](https://electron.build/configuration/configuration) like [files](https://electron.build/configuration/configuration#Config-files)). 