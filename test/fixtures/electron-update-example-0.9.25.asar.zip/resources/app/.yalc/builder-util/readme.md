# builder-util

Various utilities. Used by [electron-builder](https://github.com/electron-userland/electron-builder).