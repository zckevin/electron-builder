scp ./dist/mac/electron-updater-example.app/Contents/Resources/app.asar osx:/Applications/WebTorrent.app/Contents/Resources
