# dmg-builder

Utilities to build DMG. Used by [electron-builder](https://github.com/electron-userland/electron-builder).