const path = require('path');

class UpdateInfo {
	constructor(name, version, outDir, appOutDir) {
		this.name = name;
		this.version = version;

		// e.g. //electron-updater-example/dist/
		this.outDir = outDir;
		// e.g. //electron-updater-example/dist/linux-unpacked/
		this.appOutDir = appOutDir;

		// e.g. //electron-updater-example/dist/electron-updater-example-0.9.1.asar.zip
		this.zipFilePath = path.join(outDir, this.getZipName());

		// e.g. //electron-updater-example/dist/electron-updater-example-0.9.1.asar.zip.blockmap
		this.blockmapPath = path.join(this.zipFilePath, `../${path.basename(this.zipFilePath)}.blockmap`);

		const ymlPrefix = "asar"
		this.ymlPaths = [
			path.join(outDir, `${ymlPrefix}.yml`),
			path.join(outDir, `${ymlPrefix}-linux.yml`),
			path.join(outDir, `${ymlPrefix}-mac.yml`),
		];
	}

	getZipName() {
		return `${this.name}-${this.version}.asar.zip`;
	}

	setBlockmapInfo(info) {
		this.blockmapInfo = info;
	}
}

module.exports = UpdateInfo;