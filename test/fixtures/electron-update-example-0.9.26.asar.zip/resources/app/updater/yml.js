const path = require('path');
const { writeUpdateInfoFiles } = require("app-builder-lib");

async function genYml(context, updateInfo) {
  const info = {
    version: updateInfo.version,
    releaseDate: new Date().toISOString(),
    files: [
      {
        "url": path.basename(updateInfo.zipFilePath),
        "sha512": updateInfo.blockmapInfo.sha512,
        "size": updateInfo.blockmapInfo.size,
      }
    ],
    path: path.basename(updateInfo.zipFilePath),
    sha512: updateInfo.blockmapInfo.sha512,
  };

  const fileTasks = updateInfo.ymlPaths.map(ymlPath => {
    return {
      file: ymlPath,
      info: info,
      publishConfiguration: {
        publishAutoUpdate: true,
      },
    }
  })
  writeUpdateInfoFiles(fileTasks, context.packager);
}

module.exports = {
  genYml,
}