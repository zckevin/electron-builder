async function artifactBuildCompleted(context) {
  console.log("=== artifact build completed", context);
}

module.exports = {
  artifactBuildCompleted,
}